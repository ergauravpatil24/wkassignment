package pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class LandingPage {
	public WebDriver driver;
	
	public LandingPage (WebDriver driver) 
	{
		this.driver = driver;
	}
	
	By item1 =  By.id("todo-input");
	
	By expectedText1 = By.xpath("//label[contains(text(),'Check Emails')]");
	
	By expectedText2 = By.xpath("//label[contains(text(),'Attend DSM')]");
	
	By getText = By.xpath("//label[@data-testid='todo-item-label']");
	
	By checkbox = By.xpath("//input[@type='checkbox']");
	
	By checkedItem = By.cssSelector("a[href*='completed']");
	
	By toDosText = By.xpath("//input[contains(@placeholder, 'What needs to be done')]");
	
	public void addItem1()
	{
		driver.findElement(item1).sendKeys("Go to office");
	}

	public void addItemNoText()
	{
		driver.findElement(item1).sendKeys("");
	}

	public void addItemSingleText()
	{
		driver.findElement(item1).sendKeys("a");
	}

	public void hitEnter()
	{
		driver.findElement(item1).sendKeys(Keys.ENTER);
	}

	public void addItem2()
	{
		driver.findElement(item1).sendKeys("Check Emails");
	}
	public void addItem3()
	{
		driver.findElement(item1).sendKeys("Attend DSM");
	}
	
	public void addrandomItem()
	{
		driver.findElement(item1).sendKeys("aas");
	}

	public void addEmptyItem()
	{
		driver.findElement(item1).sendKeys("");
	}
	
	public void isChecked()
	{
		driver.findElement(checkbox).click();
	}
	
	public void itemDisplayed()
	{
		driver.findElement(checkedItem).isDisplayed();
	}
	
	public void validateItem1()
	{
		driver.findElement(expectedText1).isDisplayed();
	}

	public void validateItem2()
	{
		driver.findElement(expectedText2).isDisplayed();
	}
	
	public String validateText()
	
	{
		return driver.findElement(getText).getText();
	}

	public String validateText1()
	
	{
		return driver.findElement(expectedText1).getText();
	}

	public String validateText2()
	
	{
		return driver.findElement(expectedText2).getText();
	}

	public boolean isCheckBoxSelected()
	{
		return driver.findElement(checkbox).isSelected();
	}
	
	public String validateToDos()
	{
		return driver.findElement(toDosText).getText();
	}
	
	public void closeAll()
	{
		driver.quit();
	}

}
