package stepDefinitions;

import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pageObjects.LandingPage;

public class ToDosStepDefinition {
		public WebDriver driver;
		LandingPage lap;

		@Given("User is on To dos Landing Page")
	public void user_is_on_to_dos_landing_page() {
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\PCW\\ChromeDriver\\chromedriver.exe");
		driver = new ChromeDriver();	
		driver.get("https://todomvc.com/examples/react/dist/");
	}
	@When("User adds a valid to do item")
	public void user_adds_a_valid_to_do_item() {

		lap = new LandingPage(driver);
		lap.addItem1();
		lap.hitEnter();
		
	    
	}
	
	@Then("The item should be added to the list")
	public void the_item_should_be_added_to_the_list() {
		lap = new LandingPage(driver);
	    Assert.assertEquals(lap.validateText(), "Go to office");
	    lap.closeAll();
	}
	
	@When("User adds multiple to do items")
	public void user_adds_multiple_to_do_items() {
		lap = new LandingPage(driver);
		lap.addItem2();
		lap.hitEnter();		

		lap.addItem3();
		lap.hitEnter();
	    }
	
	@Then("The items should be added to the list")
	public void the_items_should_be_added_to_the_list() {
		lap = new LandingPage(driver);
	    Assert.assertEquals(lap.validateText1(), "Check Emails");
	    Assert.assertEquals(lap.validateText2(), "Attend DSM");
	    lap.closeAll();
	}
	
	@When("User marks single to do items as completed")
	public void user_marks_single_to_do_items_as_completed() {

		lap = new LandingPage(driver);
		lap.addItem1();
		lap.hitEnter();
		
		lap.isChecked();
		
	}
	
	@Then("The item should be marked as completed")
	public void the_item_should_be_marked_as_completed() {
		lap = new LandingPage(driver);
		lap.itemDisplayed();
		Assert.assertTrue(lap.isCheckBoxSelected());
		lap.closeAll();
	}
	
	@When("User marks multiple to do items as completed")
	public void user_marks_multiple_to_do_items_as_completed() {
		lap = new LandingPage(driver);
		lap.addItem1();
		lap.hitEnter();
		lap.isChecked();
		

		lap.addItem2();
		lap.hitEnter();
		lap.isChecked();
		
		
		lap.addItem3();
		lap.hitEnter();
		lap.isChecked();
		

	}
	@Then("The items should be marked as completed")
	public void the_items_should_be_marked_as_completed() {
		lap = new LandingPage(driver);
		driver.findElement(By.cssSelector("a[href*='completed']")).isDisplayed();
		Assert.assertTrue(lap.isCheckBoxSelected());
		
		driver.findElement(By.xpath("//label[contains(text(),'Check Emails')]")).isDisplayed();
		Assert.assertTrue(lap.isCheckBoxSelected());

		driver.findElement(By.xpath("//label[contains(text(),'Attend DSM')]")).isDisplayed();
		Assert.assertTrue(lap.isCheckBoxSelected());

		lap.closeAll();

	}
	@When("User adds an item with no text")
	public void user_adds_an_item_with_no_text() {
		lap = new LandingPage(driver);
		lap.addItemNoText();
		lap.hitEnter();
	}
	@Then("The items should not be added")
	public void the_items_should_not_be_added() {
	lap = new LandingPage(driver);
	Assert.assertFalse(false, lap.validateToDos());
	lap.closeAll();
	}
	@When("User adds an item with one character")
	public void user_adds_an_item_with_one_character() {
		lap = new LandingPage(driver);
	    lap.addItemSingleText();
	    lap.hitEnter();

	
	
	}
	@When("User checks an already unmarked item")
	public void user_checks_an_already_unmarked_item() {
		lap = new LandingPage(driver);
		Assert.assertFalse(false, lap.validateToDos());
	}
	@Then("The items should be in the unmarked list")
	public void the_items_should_be_in_the_unmarked_list() {
		lap = new LandingPage(driver);
		System.out.println(lap.validateToDos());
		lap.closeAll();
	}
	@When("User clicks on the dropdown button twice")
	public void user_clicks_on_the_dropdown_button_twice() {
		lap = new LandingPage(driver);
	    lap.addrandomItem();
	    lap.hitEnter();
	    for(int i=0;i<2;i++)
	    {
	    driver.findElement(By.xpath("//input[@type='checkbox']")).click();
	    }
	}
	@Then("The marked items should be un-marked")
	public void the_marked_items_should_be_un_marked() {
		lap = new LandingPage(driver);
		Assert.assertFalse(lap.isCheckBoxSelected());
		lap.closeAll();
	}

}
